import { Injectable } from "@angular/core";

@Injectable()
export class AuthService {
    isAuth = false;
    constructor() { }
    signInUser(login: string, password: string) {
        return new Promise(
            (resolve, reject) => {
                setTimeout(
                    () => {
                        this.isAuth = true;
                        resolve(true);
                    }, 1000
                );
            }
        );
    }
    signOutUser() {
        this.isAuth = false;
    }
}