import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { User } from '../models/User.model';

@Injectable()

export class UsersService {
    users:User[] = [
        { "id": 1, "login": "admin", "listeRole": [], "password": "0" ,"email":""}
        , { "id": 2, "login": "utilisateur","listeRole": [], "password": "1","email":"" }
    ];
    usersSubject = new Subject<User[]>();

    constructor () {}   
    emitUsers() {
        this.usersSubject.next(this.users);
    }
    getUserById(id: number) {
        const user = this.users.find(
            (userObject) => {
                return userObject.id = id;
            }
        );
    }
    saveUsers() {
    }
    getUsers() {
        //this.users = 
        this.emitUsers;
    }
    getSingleUser(id:number) {
        return new Promise(
            (resolve, reject) => {
                setTimeout(
                    () => {
                        resolve(new User(3,'3',[],'3'));
                    }, 1000
                );            
            }
        )
    }
    createNewUser(newUser : User) {
        this.users.push(newUser);
        this.saveUsers();
        this.emitUsers();
    }
    removeUser(user:User) {
        const userIndexToRemove = this.users.findIndex(
            (userEl) => {
                if (userEl==user) {
                    return true
                }
            }
        );
        this.users.splice(userIndexToRemove,1);
        this.saveUsers;
        this.emitUsers;
    }
}