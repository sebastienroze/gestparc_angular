export class User {
    email: string;
    constructor(
        public id: number,
        public login: string,
        public listeRole: string[],
        public password: string) {
    }
}