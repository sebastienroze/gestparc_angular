import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import {User} from '../models/User.model'
import { UsersService } from '../services/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit, OnDestroy {
  users:User[];
userSubscription : Subscription;
usersService:UsersService;
  constructor(usersService:UsersService,private router: Router) { 
    this.usersService = usersService;
  }

  ngOnInit(): void {
    this.userSubscription = this.usersService.usersSubject.subscribe(
      (users:User[]) => {
        this.users = users;
      }
    );
    this.usersService.emitUsers();          
  }

  onNewUser() {
    this.router.navigate(['/users','new']);    
  }
  onDeleteUser(user:User) {
    this.usersService.removeUser(user);
  }
  onViewUser(id:number) {
    this.router.navigate(['/users','view',id]);    
  }
  ngOnDestroy() {
    this.userSubscription.unsubscribe;
  }

}
