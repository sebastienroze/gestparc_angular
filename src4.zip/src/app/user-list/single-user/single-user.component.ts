import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/User.model';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-single-user',
  templateUrl: './single-user.component.html',
  styleUrls: ['./single-user.component.css']
})
export class SingleUserComponent implements OnInit {
  user: User;
  constructor(private route: ActivatedRoute,
    private userService: UsersService,
    private router: Router) { }

  ngOnInit(): void {
    this.user = new User(-1, '', [], '');
    const id = this.route.snapshot.params['id'];
    this.userService.getSingleUser(id).then(
      (user: User) => {
        this.user = user;
      }
    );
  }
  onBack() {
    this.router.navigate(['/users']);
  }
}
