import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AppParams } from "../app.params";
import { User } from "../models/User.model";

@Injectable({providedIn:'root'})
export class AuthService {
    private apiLoginUrl = 'authentication';  // URL to web api
    isAuth = false;
    constructor(
        private http: HttpClient,
        private appParams : AppParams,
    ) { }

    getLoginUrl() : string {return this.appParams.apiUrl+this.apiLoginUrl; }

    signInUser(login: string, password: string):Promise<any> {
        const url = `${this.getLoginUrl()}`;
        const user= new User(-1,login,password,null);
        return this.http.post<User>(url,JSON.stringify(user),this.appParams.httpOptions).toPromise()        
    }

    signOutUser() {
        this.isAuth = false;
        this.appParams.doLogout();
    }
}