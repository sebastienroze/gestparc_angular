import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AppParams } from "../app.params";
import { User } from '../models/User.model';

@Injectable({providedIn:'root'})

export class UsersService  {

    private apiUsersUrl = 'user/utilisateurs';  // URL to web api
    private apiUserUrl = 'user/utilisateur';  // URL to web api
    private apiNewUserUrl = 'user/utilisateur/new';  // URL to web api
    private apiUpdateUserUrl = 'user/utilisateur/update';  // URL to web api
    private apiDeleteUserUrl = 'user/utilisateur/delete';  // URL to web api

    users: User[] = [];

    constructor(
        private http: HttpClient,
        private appParams : AppParams,
    ) { }

    getUserUrl() : string {return this.appParams.apiUrl+this.apiUserUrl; }
    getUsersUrl() : string {return this.appParams.apiUrl+this.apiUsersUrl;}
    getNewUserUrl() : string {return this.appParams.apiUrl+this.apiNewUserUrl;}    
    getUpdateUserUrl() : string {return this.appParams.apiUrl+this.apiUpdateUserUrl;}    
    getDeleteUserUrl() : string {return this.appParams.apiUrl+this.apiDeleteUserUrl;}    

    getUserById(id: number): Promise<User> {
        const url = `${this.getUserUrl()}/${id}`;
        return this.http.get<User>(url,this.appParams.httpOptions).toPromise<User>();
    }

    getUsers(): Promise<User[]> {        
        const url = `${this.getUsersUrl()}`;
        return this.http.get<User[]>(url,this.appParams.httpOptions).toPromise<User[]>();
    }

    createNewUser(newUser: User):Promise<User> {
        const url = `${this.getNewUserUrl()}`;
        return this.http.post<User>(url,JSON.stringify(newUser),this.appParams.httpOptions).toPromise<User>();
    }
    UpdateUser(anUser: User):Promise<User> {
        const url = `${this.getUpdateUserUrl()}`;
        return this.http.post<User>(url,JSON.stringify(anUser),this.appParams.httpOptions).toPromise<User>();
      }
  
    removeUser(user: User):Promise<any> {
        const url = `${this.getDeleteUserUrl()}/${user.id}`;
        console.log(url);
        return this.http.get<User[]>(url,this.appParams.httpOptions).toPromise<any>();
//        return this.http.delete<User[]>(url,this.appParams.httpOptions).toPromise<any>();

    }
}