import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import {User} from '../models/User.model'
import { UsersService } from '../services/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  users:User[];

userSubscription : Subscription;
usersService:UsersService;
  constructor(usersService:UsersService,private router: Router) { 
    this.usersService = usersService;
  }

  ngOnInit(): void {
    this.usersService.getUsers()
    .then(
      (users:User[]) => {
        if (users===null) {
          console.log("Erreur à la lecture des utilisateurs");
//          this.router.navigate(['/users']);          
        } else {
          this.users=users;
      }
      }
    );
//    this.usersService.emitUsers();
  }

  onNewUser() {
    this.router.navigate(['/users','new']);    
  }
  onViewUser(id:number) {
    this.router.navigate(['/users','view',id]);    
  }


}
