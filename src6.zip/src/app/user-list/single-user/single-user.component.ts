import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { User } from 'src/app/models/User.model';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-single-user',
  templateUrl: './single-user.component.html',
  styleUrls: ['./single-user.component.css']
})
export class SingleUserComponent implements OnInit  {
  user: User;
  constructor(private route: ActivatedRoute,
    private userService: UsersService,
    private router: Router,
    ) { }

  ngOnInit(): void {
//    {login,password} as User
    const login = "";
    const password = "";
    this.user = {login,password} as User;
    const id = this.route.snapshot.params['id'];
    this.userService.getUserById(id)
    .then(
      (user:User) => {
        if (user===null) {
          console.log("Erreur à la lecture de l'utilisateur "+ id);
          this.router.navigate(['/users']);          
        } else {
          this.user=user;
        }
      }
    );
  }    

/*
    this.userService.getSingleUser(id).then(
      (user: User) => {
        this.user = user;
      }
    );
      */

  onBack() {
    this.router.navigate(['/users']);
  }

  onDeleteUser() {
    this.userService.removeUser(this.user)
    .then(
      (any:any) => {
        if (any===null) {
          console.log("Erreur à la suppression de l'utilisateur "+ this.user.id);
        } else {
          this.router.navigate(['/users']);          
        }
      });
  }

  onModify() {
    this.router.navigate(['/users','edit',this.user.id]);    
  }

}
