import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AppParams } from "../app.params";
import { User } from "../models/User.model";

@Injectable()
export class AuthService {
    private apiLoginUrl = 'authentication';  // URL to web api
    isAuth = false;
    constructor(
        private http: HttpClient,
        private appParams : AppParams,
    ) { }

    getLoginUrl() : string {return this.appParams.apiUrl+this.apiLoginUrl; }


/*    
    signInUser(login: string, password: string) {
        console.log("signin");
        return new Promise(
            (resolve, reject) => {
                setTimeout(
                    () => {
                        this.isAuth = true;
                        resolve(true);
                    }, 1000
                );
            }
        );
    }
    */
    httpOptions = {
        headers: new HttpHeaders({
//            'Accept': 'text/html, application/xhtml+xml, */*',
//            'Content-Type': 'application/x-www-form-urlencoded'            
             'Content-Type': 'application/json'
             })
//             ,observe: 'response' as 'body'
      };

      
    signInUser(login: string, password: string):Promise<any> {
        const url = `${this.getLoginUrl()}`;
//        headers.append('Authorization', 'Bearer AADDFFKKKLLLL');        
        const user= new User(-1,login,password,null);
//        return this.http.post(url, this.createLoginFormData(login, password), this.httpOptions).toPromise();        
        return this.http.post<User>(url,JSON.stringify(user),this.httpOptions).toPromise()        
    }

    signOutUser() {
        this.isAuth = false;
    }
}