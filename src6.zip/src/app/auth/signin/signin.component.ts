import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { User } from 'src/app/models/User.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})

export class SigninComponent implements OnInit, OnDestroy {
  signInForm: FormGroup;
  errorMessage: string;
  private authServiceSubscription: Subscription;

  constructor(private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router) { }

  ngOnInit(): void {
    this.initForm();
  }
  
  initForm() {
    this.signInForm = this.formBuilder.group({
          login: ['', []],
          password: ['', []]

      //,Validators.pattern("[0-9a-zA-Z]{6,}")      
//      password: ['', [Validators.required]]
//          login: ['', [Validators.required]],

    })
  }

  onSubmit() {
    const login = this.signInForm.get("login").value;
    const password = this.signInForm.get("password").value;
/*
    this.authServiceSubscription = this.authService.signInUser(login, password).subscribe(
      (user: User) => {
        if (user === null) {
          console.log("Erreur à l'authentification");
        } else {
          this.router.navigate(["/users"]);    
        }
      }
      ),(error: any) => console.log("Error: ", error);
*/
    
    this.authService.signInUser(login, password).then(
      (beaver:any) => {
        console.log(beaver.beaver)
        this.authService.isAuth = true;        
        this.router.navigate(["/users"]);
      }, (error) => {
        console.log(error);
        this.errorMessage = error.error;
      }
    );

  }
  ngOnDestroy() {
    if (this.authServiceSubscription!=null) this.authServiceSubscription.unsubscribe()
  }  
}
