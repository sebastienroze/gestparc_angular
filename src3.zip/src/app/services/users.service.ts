export class UsersService {
    users = [
        { "id": 1, "login": "admin", "listeRole": [], "password": "0" }
        , { "id": 2, "login": "utilisateur", "listeRole": [], "password": "1" }
    ];

    getUserById(id: number) {
        const user = this.users.find(
            (userObject) => {
                return userObject.id = id;
            }
        );
    }
}