import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-guard',
  templateUrl: './auth-guard.component.html',
  styleUrls: ['./auth-guard.component.css']
})
export class AuthGuardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
