import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SigninComponent } from './auth/signin/signin.component';
import { UserListComponent } from './user-list/user-list.component';
import { SingleUserComponent } from './user-list/single-user/single-user.component';
import { UserFormComponent } from './user-list/user-form/user-form.component';
import { HeaderComponent } from './header/header.component';
import { AuthComponent } from './services/auth/auth.component';
import { UsersComponent } from './services/users/users.component';
import { AuthGuardComponent } from './services/auth-guard/auth-guard.component';
import { AuthService } from './services/auth.service';
import { UsersService } from './services/users.service';
import { AuthGuardService } from './services/auth-guard.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
  { path: 'auth/signin', component: SigninComponent },
  { path: 'users', component: UserListComponent },
  { path: 'users/new', component: UserFormComponent },
  { path: 'users/view/:id', component: SingleUserComponent },
  { path: 'users/edit/:id', component: UserFormComponent },
  { path: '', redirectTo: 'users',pathMatch : 'full' },
  { path: '**', redirectTo: 'users'}
]
@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    UserListComponent,
    SingleUserComponent,
    UserFormComponent,
    HeaderComponent,
    AuthComponent,
    UsersComponent,
    AuthGuardComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    AuthService,
    AuthGuardService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
