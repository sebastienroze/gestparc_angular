import { Role } from "./Role.model";

/*
export interface User {
        id: number;
        login: string;
        password: string ;
        listeRole: string[];

}

        public listeRole: string,

*/
export class User {
    //    email: string;
    constructor(
        public id: number,
        public login: string,
        public password: string,
        public listeRole: Role[],
        ) {  }
}
