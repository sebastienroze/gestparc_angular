import { Injectable } from '@angular/core';
@Injectable({providedIn:'root'})

export class AppParams {
  apiUrl: string = 'http://localhost:8080/';
}