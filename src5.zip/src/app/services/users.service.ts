import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { AppParams } from "../app.params";
import { User } from '../models/User.model';

@Injectable({providedIn:'root'})

export class UsersService  {

    private apiUsersUrl = 'user/utilisateurs';  // URL to web api
    private apiUserUrl = 'user/utilisateur';  // URL to web api
    private apiNewUserUrl = 'user/utilisateur/new';  // URL to web api
    private apiUpdateUserUrl = 'user/utilisateur/update';  // URL to web api
    private apiDeleteUserUrl = 'user/utilisateur/delete';  // URL to web api

    users: User[] = [];
    usersSubject = new Subject<User[]>();

    constructor(
        private http: HttpClient,
        private appParams : AppParams,
    ) { }

    getUserUrl() : string {return this.appParams.apiUrl+this.apiUserUrl; }
    getUsersUrl() : string {return this.appParams.apiUrl+this.apiUsersUrl;}
    getNewUserUrl() : string {return this.appParams.apiUrl+this.apiNewUserUrl;}    
    getUpdateUserUrl() : string {return this.appParams.apiUrl+this.apiUpdateUserUrl;}    
    getDeleteUserUrl() : string {return this.appParams.apiUrl+this.apiDeleteUserUrl;}    

    emitUsers() {
        this.usersSubject.next(this.users);
    }

    getUserById(id: number): Observable<User> {
        const url = `${this.getUserUrl()}/${id}`;
        return this.http.get<User>(url).pipe();
    }

    saveUsers() {
    }

    getUsers(): Observable<User[]> {
        const url = `${this.getUsersUrl()}`;
        return this.http.get<User[]>(url).pipe();
    }

    /*
    getUsers() {
        this.emitUsers;
    }
    */
    httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' })
      };

    createNewUser(newUser: User):Observable<User> {
        const url = `${this.getNewUserUrl()}`;
//        headers.append('Authorization', 'Bearer AADDFFKKKLLLL');        
        return this.http.post<User>(url,JSON.stringify(newUser),this.httpOptions).pipe();
    }
    UpdateUser(anUser: User):Observable<User> {
        const url = `${this.getUpdateUserUrl()}`;
        return this.http.post<User>(url,JSON.stringify(anUser),this.httpOptions).pipe();
      }
  
    removeUser(user: User):Observable<any> {
        const url = `${this.getDeleteUserUrl()}/${user.id}`;
        console.log(url);
        return this.http.get<User[]>(url).pipe();
//        return this.http.delete<User>(url);
    }
}