import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})

export class SigninComponent implements OnInit {
  signInForm: FormGroup;
  errorMessage: string;

  constructor(private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router) { }

  ngOnInit(): void {
    this.initForm();
  }
  
  initForm() {
    this.signInForm = this.formBuilder.group({
          login: ['', []],
          password: ['', []]

      //,Validators.pattern("[0-9a-zA-Z]{6,}")      
//      password: ['', [Validators.required]]
//          login: ['', [Validators.required]],

    })
  }

  onSubmit() {
    const login = this.signInForm.get("login").value;
    const password = this.signInForm.get("password").value;
    this.router.navigate(["/users"]);    
    
    this.authService.signInUser(login, password).then(
      () => {
        this.router.navigate(["/users"]);
      }, (error) => {
        this.errorMessage = error;
      }
    );
  }
}
