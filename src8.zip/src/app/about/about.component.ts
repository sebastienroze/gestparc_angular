import { Component, OnInit } from '@angular/core';
import { AppParams } from '../app.params';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  public version =0;
  constructor(
    private appParams : AppParams,
  ) { }

  ngOnInit(): void {
    this.version = this.appParams.applicationVersion;
  }
}
