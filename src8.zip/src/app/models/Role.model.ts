export class Role {
        constructor(
                public id: number,
                public denomination: string,
                ) {  }        
}
